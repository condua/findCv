import React from 'react'

const IRAHero = () => {
  return (
    <div className=' bg-gradient-to-r from-cyan-500 via-orange-600 to-green-500 h-24 mt-5 mr-4 rounded-lg'></div>
  )
}

export default IRAHero