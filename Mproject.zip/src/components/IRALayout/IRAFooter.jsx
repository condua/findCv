import React from 'react'

const  IRAFooter = () => {
  return (
    <div className='w-full bg-black' >IRAFooter</div>
  )
}

export default  IRAFooter