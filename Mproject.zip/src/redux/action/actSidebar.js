const actSidebar = {
    SET_COLLAPSED: "SET_COLLAPSED",
    SET_SELECTED_LABEL: "SET_SELECTED_LABEL",
    SET_CONTENT: "SET_CONTENT",
}

export default actSidebar
