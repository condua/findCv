import React from 'react';
import "./Interview.scss"
import Header from "./../Header/Header";
import CVBuilder from "./../CVBuilder/CVBuilder";

function Interview(){
    return (
        <>
        <Header/>
        <CVBuilder/>
        </>
    )
}

export default Interview;